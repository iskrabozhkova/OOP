#include <iostream>
#include "Catalogue.hpp"
using namespace std;

int main() {
	Catalogue().printMenu();
	return 0;
}