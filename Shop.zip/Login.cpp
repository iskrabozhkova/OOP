#include <iostream>
#include "Login.hpp"


Login::Login() : username(" "), password(" "){
}
