#pragma once

class Catalogue {
public:
	void printMenu();
};
